package com.essentialsx.configurator;

import net.md_5.bungee.api.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class EssxConfigCommand implements CommandExecutor, TabCompleter {
    private final EssentialsXConfiguratorPlugin plugin;

    public EssxConfigCommand(EssentialsXConfiguratorPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Check if sender is a player and has permissions
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command can only be used by players.");
            return true;
        }

        Player player = (Player) sender;

        // Permission checks
        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "get":
                if (!player.hasPermission("essxconfig.view")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to view config values.");
                    return true;
                }
                if (args.length < 2) {
                    player.sendMessage(ChatColor.RED + "Usage: /essxconfig get <key>");
                    return true;
                }
                getConfigValue(player, args[1]);
                break;

            case "set":
                if (!player.hasPermission("essxconfig.edit")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to edit config values.");
                    return true;
                }
                if (args.length < 3) {
                    player.sendMessage(ChatColor.RED + "Usage: /essxconfig set <key> <value>");
                    return true;
                }
                setConfigValue(player, args[1], args[2]);
                break;

            case "list":
                if (!player.hasPermission("essxconfig.view")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to list config values.");
                    return true;
                }
                listConfigKeys(player);
                break;

            case "reload":
                if (!player.hasPermission("essxconfig.reload")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to reload the config.");
                    return true;
                }
                reloadConfig(player);
                break;

            default:
                sendHelp(player);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        
        if (!(sender instanceof Player)) {
            return completions;
        }
        
        if (args.length == 1) {
            // First argument suggestions
            List<String> subCommands = List.of("get", "set", "list", "reload");
            for (String subCmd : subCommands) {
                if (subCmd.startsWith(args[0].toLowerCase())) {
                    completions.add(subCmd);
                }
            }
        } else if (args.length == 2) {
            switch (args[0].toLowerCase()) {
                case "get":
                case "set":
                    // Suggest config keys for get and set commands
                    Set<String> keys = plugin.getEssentialsPlugin().getConfig().getKeys(true);
                    for (String key : keys) {
                        if (key.toLowerCase().startsWith(args[1].toLowerCase())) {
                            completions.add(key);
                        }
                    }
                    break;
            }
        }
        
        return completions;
    }

    private void sendHelp(Player player) {
        player.sendMessage(ChatColor.GOLD + "EssentialsX Configurator Help:");
        player.sendMessage(ChatColor.YELLOW + "/essxconfig get <key> - View a config value");
        player.sendMessage(ChatColor.YELLOW + "/essxconfig set <key> <value> - Set a config value");
        player.sendMessage(ChatColor.YELLOW + "/essxconfig list - List all config keys");
        player.sendMessage(ChatColor.YELLOW + "/essxconfig reload - Reload EssentialsX config");
    }

    private void getConfigValue(Player player, String key) {
        Object value = plugin.getConfigValue(key);
        if (value != null) {
            player.sendMessage(ChatColor.GREEN + "Config Value for " + key + ": " + value.toString());
        } else {
            player.sendMessage(ChatColor.RED + "Config key not found: " + key);
        }
    }

    private void setConfigValue(Player player, String key, String value) {
        // Basic type conversion and validation
        Object parsedValue = parseValue(value);
        
        if (plugin.setConfigValue(key, parsedValue)) {
            player.sendMessage(ChatColor.GREEN + "Config value set successfully: " + key + " = " + value);
            
            // Log the configuration change
            plugin.getLogger().info("Config value changed by " + player.getName() + ": " + key + " = " + value);
        } else {
            player.sendMessage(ChatColor.RED + "Failed to set config value. Check console for details.");
        }
    }

    private void listConfigKeys(Player player) {
        Set<String> keys = plugin.getEssentialsPlugin().getConfig().getKeys(true);
        player.sendMessage(ChatColor.GOLD + "Available Config Keys:");
        keys.stream()
            .limit(20)  // Limit to prevent spam
            .forEach(key -> player.sendMessage(ChatColor.YELLOW + "- " + key));
        
        if (keys.size() > 20) {
            player.sendMessage(ChatColor.GRAY + "... and " + (keys.size() - 20) + " more.");
        }
    }

    private void reloadConfig(Player player) {
        try {
            plugin.reloadEssentialsConfig();
            player.sendMessage(ChatColor.GREEN + "EssentialsX configuration reloaded successfully.");
        } catch (Exception e) {
            player.sendMessage(ChatColor.RED + "Failed to reload configuration. Check console for details.");
            plugin.getLogger().severe("Config reload failed: " + e.getMessage());
        }
    }

    // Basic value parsing method
    private Object parseValue(String value) {
        // Try to parse as boolean
        if (value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false")) {
            return Boolean.parseBoolean(value);
        }
        
        // Try to parse as integer
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            // Try to parse as double
            try {
                return Double.parseDouble(value);
            } catch (NumberFormatException ex) {
                // Return as string if no other parsing works
                return value;
            }
        }
    }
}

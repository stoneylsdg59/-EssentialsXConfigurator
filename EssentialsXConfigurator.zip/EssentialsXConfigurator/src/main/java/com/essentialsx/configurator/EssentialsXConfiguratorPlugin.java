package com.essentialsx.configurator;

import net.ess3.api.IEssentials;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;

public class EssentialsXConfiguratorPlugin extends JavaPlugin {
    private IEssentials essentialsPlugin;
    private File essentialsConfigFile;
    private YamlConfiguration essentialsConfig;
    private static final String[] SUPPORTED_VERSIONS = {"1.19.4", "1.20.4", "1.20.6", "1.21.1"};

    @Override
    public void onEnable() {
        // Check Minecraft server version compatibility
        if (!isCompatibleVersion()) {
            getLogger().severe("Unsupported Minecraft version. Supported versions: 1.19.4, 1.20.4, 1.20.6, 1.21.1");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        // Validate EssentialsX dependency
        Plugin essentials = Bukkit.getPluginManager().getPlugin("Essentials");
        if (!(essentials instanceof IEssentials)) {
            getLogger().severe("EssentialsX not found! This plugin requires EssentialsX to function.");
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }
        
        this.essentialsPlugin = (IEssentials) essentials;
        this.essentialsConfigFile = new File(essentialsPlugin.getDataFolder(), "config.yml");
        this.essentialsConfig = YamlConfiguration.loadConfiguration(essentialsConfigFile);

        // Register command using Bukkit's command map
        EssxConfigCommand configCommand = new EssxConfigCommand(this);
        getCommand("essxconfig").setExecutor(configCommand);
        getCommand("essxconfig").setTabCompleter(configCommand);

        getLogger().info("\u001B[32mCreated by StoneyG59\u001B[0m");
        getLogger().info("EssentialsX Configurator has been enabled!");
    }

    // Version compatibility check
    private boolean isCompatibleVersion() {
        String serverVersion = Bukkit.getServer().getBukkitVersion().split("-")[0];
        for (String supportedVersion : SUPPORTED_VERSIONS) {
            if (serverVersion.startsWith(supportedVersion)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void onDisable() {
        getLogger().info("EssentialsX Configurator has been disabled.");
    }

    // Method to get current config value
    public Object getConfigValue(String key) {
        return essentialsConfig.get(key);
    }

    // Method to set config value
    public boolean setConfigValue(String key, Object value) {
        try {
            essentialsConfig.set(key, value);
            essentialsConfig.save(essentialsConfigFile);
            return true;
        } catch (IOException e) {
            getLogger().log(Level.SEVERE, "Could not save configuration file", e);
            return false;
        }
    }

    // Method to reload EssentialsX configuration
    public void reloadEssentialsConfig() {
        essentialsPlugin.reload();
    }

    // Getter for EssentialsX plugin
    public IEssentials getEssentialsPlugin() {
        return essentialsPlugin;
    }
}
